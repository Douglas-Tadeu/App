class Avaliacao {
  final String id;
  final String usuarioId;
  final String pratoId;
  final double nota;
  final String comentario;
  final DateTime? data;

  Avaliacao({
    required this.id,
    required this.usuarioId,
    required this.pratoId,
    required this.nota,
    required this.comentario,
    this.data,
  });

  factory Avaliacao.fromJson(Map<String, dynamic> json) {
    DateTime? parseData(dynamic v) {
      if (v == null) return null;
      if (v is DateTime) return v;
      try {
        return DateTime.parse(v.toString());
      } catch (_) {
        return null;
      }
    }

    double parseNota(dynamic v) {
      if (v == null) return 0.0;
      if (v is num) return v.toDouble();
      return double.tryParse(v.toString()) ?? 0.0;
    }

    return Avaliacao(
      id: json['id']?.toString() ?? json['_id']?.toString() ?? '',
      usuarioId: json['usuarioId']?.toString() ?? '',
      pratoId: json['pratoId']?.toString() ?? '',
      nota: parseNota(json['nota']),
      comentario: json['comentario'] ?? '',
      data: parseData(json['data'] ?? json['createdAt'] ?? json['date']),
    );
  }

  Map<String, dynamic> toJson() {
    return {
      'id': id,
      'usuarioId': usuarioId,
      'pratoId': pratoId,
      'nota': nota,
      'comentario': comentario,
      'data': data?.toIso8601String(),
    };
  }
}
