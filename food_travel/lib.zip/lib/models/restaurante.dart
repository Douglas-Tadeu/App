class Restaurante {
  final String id;
  final String nome;
  final String endereco;
  final String usuarioId; // dono
  final String imageUrl;

  Restaurante({
    required this.id,
    required this.nome,
    required this.endereco,
    required this.usuarioId,
    required this.imageUrl,
  });

  factory Restaurante.fromJson(Map<String, dynamic> json) {
    return Restaurante(
      id: json['id']?.toString() ?? '',
      nome: json['nome'] ?? '',
      endereco: json['endereco'] ?? '',
      usuarioId: json['usuarioId']?.toString() ?? json['donoId']?.toString() ?? '',
      imageUrl: json['imageUrl'] ?? json['imagemUrl'] ?? '',
    );
  }

  Map<String, dynamic> toJson() {
    return {
      'id': id,
      'nome': nome,
      'endereco': endereco,
      'usuarioId': usuarioId,
      'imageUrl': imageUrl,
    };
  }
}
