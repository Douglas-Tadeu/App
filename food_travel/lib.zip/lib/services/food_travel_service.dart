import 'dart:convert';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:uuid/uuid.dart';

import '../models/usuario.dart';
import '../models/restaurante.dart';
import '../models/prato.dart';
import '../models/avaliacao.dart';
import '../models/favorito.dart';

class FoodTravelService {
  static const _KEY_USUARIOS = "ft_usuarios";
  static const _KEY_RESTAURANTES = "ft_restaurantes";
  static const _KEY_PRATOS = "ft_pratos";
  static const _KEY_AVALIACOES = "ft_avaliacoes";
  static const _KEY_FAVORITOS = "ft_favoritos";

  // =======================
  // MÉTODOS AUXILIARES
  // =======================

  Future<SharedPreferences> get _prefs async =>
      await SharedPreferences.getInstance();

  final Uuid _uuid = const Uuid();

  // =======================
  // USUÁRIO LOGADO
  // =======================

  Future<void> salvarUsuarioLogado(String id) async {
    final p = await _prefs;
    await p.setString("ft_usuario_logado", id);
  }

  Future<String?> usuarioLogado() async {
    final p = await _prefs;
    return p.getString("ft_usuario_logado");
  }

  // =======================
  // CARREGAR E SALVAR LISTAS
  // =======================

  Future<List<Usuario>> _loadUsuarios() async {
    final p = await _prefs;
    final jsonStr = p.getString(_KEY_USUARIOS);
    if (jsonStr == null) return [];
    return (json.decode(jsonStr) as List)
        .map((e) => Usuario.fromJson(e))
        .toList();
  }

  Future<void> _saveUsuarios(List<Usuario> lista) async {
    final p = await _prefs;
    await p.setString(
        _KEY_USUARIOS, json.encode(lista.map((e) => e.toJson()).toList()));
  }

  Future<List<Restaurante>> _loadRestaurantes() async {
    final p = await _prefs;
    final jsonStr = p.getString(_KEY_RESTAURANTES);
    if (jsonStr == null) return [];
    return (json.decode(jsonStr) as List)
        .map((e) => Restaurante.fromJson(e))
        .toList();
  }

  Future<void> _saveRestaurantes(List<Restaurante> lista) async {
    final p = await _prefs;
    await p.setString(_KEY_RESTAURANTES,
        json.encode(lista.map((e) => e.toJson()).toList()));
  }

  Future<List<Prato>> _loadPratos() async {
    final p = await _prefs;
    final jsonStr = p.getString(_KEY_PRATOS);
    if (jsonStr == null) return [];
    return (json.decode(jsonStr) as List)
        .map((e) => Prato.fromJson(e))
        .toList();
  }

  Future<void> _savePratos(List<Prato> lista) async {
    final p = await _prefs;
    await p.setString(_KEY_PRATOS,
        json.encode(lista.map((e) => e.toJson()).toList()));
  }

  Future<List<Avaliacao>> _loadAvaliacoes() async {
    final p = await _prefs;
    final jsonStr = p.getString(_KEY_AVALIACOES);
    if (jsonStr == null) return [];
    return (json.decode(jsonStr) as List)
        .map((e) => Avaliacao.fromJson(e))
        .toList();
  }

  Future<void> _saveAvaliacoes(List<Avaliacao> lista) async {
    final p = await _prefs;
    await p.setString(_KEY_AVALIACOES,
        json.encode(lista.map((e) => e.toJson()).toList()));
  }

  Future<List<Favorito>> _loadFavoritos() async {
    final p = await _prefs;
    final jsonStr = p.getString(_KEY_FAVORITOS);
    if (jsonStr == null) return [];
    return (json.decode(jsonStr) as List)
        .map((e) => Favorito.fromJson(e))
        .toList();
  }

  Future<void> _saveFavoritos(List<Favorito> lista) async {
    final p = await _prefs;
    await p.setString(_KEY_FAVORITOS,
        json.encode(lista.map((e) => e.toJson()).toList()));
  }

  // =======================
  // CRUD USUÁRIOS
  // =======================

  Future<void> cadastrarUsuario(Usuario u) async {
    final lista = await _loadUsuarios();
    lista.add(u);
    await _saveUsuarios(lista);
  }

  Future<Usuario?> buscarUsuarioPorEmailSenha(String email, String senha) async {
    final lista = await _loadUsuarios();
    return lista.firstWhere(
        (u) => u.email == email && u.senha == senha,
        orElse: () => null);
  }

  // =======================
  // CRUD RESTAURANTES
  // =======================

  Future<void> adicionarRestaurante(Restaurante r) async {
    final lista = await _loadRestaurantes();
    lista.add(r);
    await _saveRestaurantes(lista);
  }

  Future<List<Restaurante>> listarRestaurantes() async {
    return await _loadRestaurantes();
  }

  // =======================
  // CRUD PRATOS
  // =======================

  Future<void> adicionarPrato(Prato p) async {
    final lista = await _loadPratos();
    lista.add(p);
    await _savePratos(lista);
  }

  Future<List<Prato>> listarPratosPorRestaurante(String restauranteId) async {
    final lista = await _loadPratos();
    return lista.where((p) => p.restauranteId == restauranteId).toList();
  }

  Prato? buscarPratoPorId(String id) {
    // versão síncrona porque não depende de UI
    return null; // vai ser substituído abaixo
  }

  Future<Prato?> buscarPratoPorIdAsync(String id) async {
    final lista = await _loadPratos();
    try {
      return lista.firstWhere((p) => p.id == id);
    } catch (_) {
      return null;
    }
  }

  // =======================
  // CRUD AVALIAÇÕES
  // =======================

  Future<void> adicionarAvaliacao(Avaliacao a) async {
    final lista = await _loadAvaliacoes();
    lista.add(a);
    await _saveAvaliacoes(lista);
  }

  Future<void> atualizarAvaliacao(Avaliacao a) async {
    final lista = await _loadAvaliacoes();
    final index = lista.indexWhere((x) => x.id == a.id);
    if (index >= 0) {
      lista[index] = a;
      await _saveAvaliacoes(lista);
    }
  }

  Future<void> removerAvaliacao(String id) async {
    final lista = await _loadAvaliacoes();
    lista.removeWhere((a) => a.id == id);
    await _saveAvaliacoes(lista);
  }

  List<Avaliacao> listarAvaliacoesPorPratoSync(
      List<Avaliacao> lista, String pratoId) {
    return lista.where((a) => a.pratoId == pratoId).toList();
  }

  Future<List<Avaliacao>> listarAvaliacoesPorPrato(String pratoId) async {
    final lista = await _loadAvaliacoes();
    return lista.where((a) => a.pratoId == pratoId).toList();
  }

  // =======================
  // REGRAS DE NEGÓCIO
  // =======================

  /// Verifica se o usuário pode avaliar (não avaliou antes)
  Future<bool> usuarioPodeAvaliar(String usuarioId, String pratoId) async {
    final avaliacoes = await _loadAvaliacoes();
    final jaAvaliou = avaliacoes.any(
        (a) => a.usuarioId == usuarioId && a.pratoId == pratoId);
    return !jaAvaliou;
  }

  /// Verifica se o usuário é dono do prato
  Future<bool> usuarioEhDonoDoPrato(String usuarioId, String pratoId) async {
    final pratos = await _loadPratos();
    final prato = pratos.firstWhere((p) => p.id == pratoId, orElse: () => Prato.vazio());
    return prato.usuarioId == usuarioId;
  }

  // =======================
  // FAVORITOS
  // =======================

  Future<void> adicionarFavorito(Favorito f) async {
    final lista = await _loadFavoritos();
    lista.add(f);
    await _saveFavoritos(lista);
  }

  Future<void> removerFavorito(String id) async {
    final lista = await _loadFavoritos();
    lista.removeWhere((f) => f.id == id);
    await _saveFavoritos(lista);
  }

  Future<List<Favorito>> listarFavoritos(String usuarioId) async {
    final lista = await _loadFavoritos();
    return lista.where((f) => f.usuarioId == usuarioId).toList();
  }
}
