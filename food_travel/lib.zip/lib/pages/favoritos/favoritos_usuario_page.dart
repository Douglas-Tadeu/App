import 'package:flutter/material.dart';
import '../../../controllers/favorito_controller.dart';
import '../../../controllers/auth_controller.dart';
import '../../../models/favorito.dart';

class FavoritosUsuarioPage extends StatefulWidget {
  const FavoritosUsuarioPage({super.key});

  @override
  State<FavoritosUsuarioPage> createState() => _FavoritosUsuarioPageState();
}

class _FavoritosUsuarioPageState extends State<FavoritosUsuarioPage> {
  final favoritoController = FavoritoController();
  final auth = AuthController.instance;

  bool loading = true;
  List<Favorito> favoritos = [];

  @override
  void initState() {
    super.initState();
    carregarFavoritos();
  }

  Future<void> carregarFavoritos() async {
    final userId = await auth.getUsuarioLogado();

    if (userId == null) {
      setState(() {
        loading = false;
      });
      return;
    }

    final lista = await favoritoController.listarPorUsuario(userId);
    setState(() {
      favoritos = lista;
      loading = false;
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text("Meus Favoritos")),
      body: loading
          ? const Center(child: CircularProgressIndicator())
          : favoritos.isEmpty
              ? const Center(child: Text("Nenhum prato favoritado ainda"))
              : ListView.builder(
                  itemCount: favoritos.length,
                  itemBuilder: (context, index) {
                    final f = favoritos[index];
                    return ListTile(
                      leading: const Icon(Icons.favorite, color: Colors.red),
                      title: Text(f.pratoNome ?? "Prato"),
                      subtitle: Text("Restaurante: ${f.restauranteNome ?? '---'}"),
                      onTap: () {
                        // abrir detalhes do prato
                        Navigator.pushNamed(context, "/pratos", arguments: [f.prato]);
                      },
                    );
                  },
                ),
    );
  }
}
