import 'package:flutter/material.dart';
import '../../models/favorito.dart';
import '../../services/food_travel_service.dart';

class FavoritoListPage extends StatefulWidget {
  final FoodTravelService service;

  const FavoritoListPage({super.key, required this.service});

  @override
  State<FavoritoListPage> createState() => _FavoritoListPageState();
}

class _FavoritoListPageState extends State<FavoritoListPage> {
  List<Favorito> favoritos = [];

  @override
  void initState() {
    super.initState();
    _carregar();
  }

  void _carregar() {
    setState(() {
      favoritos = widget.service.listarFavoritos();
    });
  }

  Future<void> _excluir(String id) async {
    widget.service.removerFavorito(id);
    _carregar();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text("Favoritos cadastrados")),
      body: favoritos.isEmpty
          ? const Center(child: Text("Nenhum favorito encontrado."))
          : ListView.builder(
              itemCount: favoritos.length,
              itemBuilder: (_, i) {
                final fav = favoritos[i];
                final prato = widget.service.obterPratoPorId(fav.pratoId);

                return ListTile(
                  title: Text(prato?.nome ?? "Prato não encontrado"),
                  subtitle: Text("Usuário: ${fav.usuarioId}"),
                  trailing: IconButton(
                    icon: const Icon(Icons.delete),
                    onPressed: () => _excluir(fav.id),
                  ),
                );
              },
            ),
    );
  }
}
