import 'package:flutter/material.dart';
import '../../models/prato.dart';
import '../../models/avaliacao.dart';
import '../../services/food_travel_service.dart';

class AvaliarPratoPage extends StatefulWidget {
  final Prato prato;

  const AvaliarPratoPage({super.key, required this.prato});

  @override
  State<AvaliarPratoPage> createState() => _AvaliarPratoPageState();
}

class _AvaliarPratoPageState extends State<AvaliarPratoPage> {
  final _formKey = GlobalKey<FormState>();
  final _comentarioController = TextEditingController();
  double _nota = 3.0;
  bool _isLoading = false;

  Future<void> _salvar() async {
    if (!_formKey.currentState!.validate()) return;

    setState(() => _isLoading = true);

    final avaliacao = Avaliacao(
      id: const Uuid().v4(),
      pratoId: widget.prato.id,
      usuarioId: FoodTravelService.usuarioLogado!.id,
      comentario: _comentarioController.text.trim(),
      nota: _nota,
      data: DateTime.now(),
    );

    await FoodTravelService.salvarAvaliacao(avaliacao);

    setState(() => _isLoading = false);

    if (mounted) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(
          content: Text("Avaliação salva com sucesso!"),
          backgroundColor: Colors.green,
        ),
      );
      Navigator.pop(context, true);
    }
  }

  @override
  Widget build(BuildContext context) {
    final prato = widget.prato;

    return Scaffold(
      appBar: AppBar(
        title: Text("Avaliar ${prato.nome}"),
      ),
      body: Padding(
        padding: const EdgeInsets.all(16),
        child: Form(
          key: _formKey,
          child: Column(
            children: [
              Text(
                prato.nome,
                style: const TextStyle(fontSize: 20, fontWeight: FontWeight.bold),
              ),
              const SizedBox(height: 20),

              // Slider de nota
              Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  const Text("Nota:"),
                  Text(_nota.toStringAsFixed(1)),
                ],
              ),
              Slider(
                value: _nota,
                min: 1,
                max: 5,
                divisions: 8,
                label: _nota.toStringAsFixed(1),
                onChanged: (value) {
                  setState(() => _nota = value);
                },
              ),

              const SizedBox(height: 20),

              // Comentário
              TextFormField(
                controller: _comentarioController,
                decoration: const InputDecoration(
                  labelText: "Comentário",
                  border: OutlineInputBorder(),
                ),
                maxLines: 3,
                validator: (value) =>
                    value == null || value.trim().isEmpty ? "Digite um comentário" : null,
              ),

              const SizedBox(height: 20),

              _isLoading
                  ? const CircularProgressIndicator()
                  : ElevatedButton(
                      onPressed: _salvar,
                      child: const Text("Salvar Avaliação"),
                    ),
            ],
          ),
        ),
      ),
    );
  }
}
