import 'package:flutter/material.dart';
import '../../controllers/usuario_controller.dart';

class UsuarioFormPage extends StatefulWidget {
  final String? usuarioId;

  const UsuarioFormPage({super.key, this.usuarioId});

  @override
  State<UsuarioFormPage> createState() => _UsuarioFormPageState();
}

class _UsuarioFormPageState extends State<UsuarioFormPage> {
  final controller = UsuarioController();

  Map<String, dynamic>? usuario;
  bool loading = true;

  @override
  void initState() {
    super.initState();
    if (widget.usuarioId != null) {
      carregarUsuario();
    } else {
      loading = false;
    }
  }

  Future<void> carregarUsuario() async {
    final data = await controller.buscarUsuario(widget.usuarioId!);
    setState(() {
      usuario = data;
      loading = false;
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text(widget.usuarioId == null ? "Novo Usuário" : "Editar Usuário"),
      ),
      body: loading
          ? const Center(child: CircularProgressIndicator())
          : Padding(
              padding: const EdgeInsets.all(16),
              child: Column(
                children: [
                  TextFormField(
                    initialValue: usuario?["nome"] ?? "",
                    decoration: const InputDecoration(labelText: "Nome"),
                  ),
                  TextFormField(
                    initialValue: usuario?["email"] ?? "",
                    decoration: const InputDecoration(labelText: "E-mail"),
                  ),
                ],
              ),
            ),
    );
  }
}
