import 'package:flutter/material.dart';
import '../../controllers/restaurante_controller.dart';
import '../../models/restaurante.dart';
import '../pratos/prato_list_page.dart';

class HomePage extends StatefulWidget {
  const HomePage({super.key});

  @override
  State<HomePage> createState() => _HomePageState();
}

class _HomePageState extends State<HomePage> {
  final RestauranteController controller = RestauranteController();
  late Future<List<Restaurante>> restaurantesFuture;

  @override
  void initState() {
    super.initState();
    restaurantesFuture = carregarRestaurantes();
  }

  Future<List<Restaurante>> carregarRestaurantes() async {
    final listaJson = await controller.listarRestaurantes();
    return listaJson.map((e) => Restaurante.fromJson(e)).toList();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text("Restaurantes"),
        centerTitle: true,
      ),
      body: FutureBuilder<List<Restaurante>>(
        future: restaurantesFuture,
        builder: (context, snapshot) {
          if (snapshot.connectionState == ConnectionState.waiting) {
            return const Center(child: CircularProgressIndicator());
          }

          if (snapshot.hasError) {
            return const Center(child: Text("Erro ao carregar restaurantes."));
          }

          if (!snapshot.hasData || snapshot.data!.isEmpty) {
            return const Center(child: Text("Nenhum restaurante encontrado."));
          }

          final restaurantes = snapshot.data!;

          return ListView.builder(
            itemCount: restaurantes.length,
            itemBuilder: (context, index) {
              final r = restaurantes[index];

              return Card(
                margin: const EdgeInsets.symmetric(vertical: 8, horizontal: 12),
                child: ListTile(
                  contentPadding: const EdgeInsets.all(12),
                  leading: ClipRRect(
                    borderRadius: BorderRadius.circular(8),
                    child: Image.network(
                      r.imageUrl,
                      width: 70,
                      height: 70,
                      fit: BoxFit.cover,
                      errorBuilder: (context, error, stackTrace) =>
                          const Icon(Icons.image, size: 50),
                    ),
                  ),
                  title: Text(
                    r.nome,
                    style: const TextStyle(fontSize: 18, fontWeight: FontWeight.bold),
                  ),
                  subtitle: Text(r.endereco),
                  onTap: () {
                    Navigator.push(
                      context,
                      MaterialPageRoute(
                        builder: (context) => PratoListPage(restauranteId: r.id),
                      ),
                    );
                  },
                ),
              );
            },
          );
        },
      ),
    );
  }
}
