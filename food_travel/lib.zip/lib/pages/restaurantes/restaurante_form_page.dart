import 'package:flutter/material.dart';
import '../../controllers/restaurante_controller.dart';
import '../../models/restaurante.dart';

class RestauranteFormPage extends StatefulWidget {
  final Restaurante? restaurante;

  const RestauranteFormPage({super.key, this.restaurante});

  @override
  State<RestauranteFormPage> createState() => _RestauranteFormPageState();
}

class _RestauranteFormPageState extends State<RestauranteFormPage> {
  final _formKey = GlobalKey<FormState>();

  final nomeController = TextEditingController();
  final enderecoController = TextEditingController();
  final imageUrlController = TextEditingController();

  @override
  void initState() {
    super.initState();

    if (widget.restaurante != null) {
      nomeController.text = widget.restaurante!.nome;
      enderecoController.text = widget.restaurante!.endereco;
      imageUrlController.text = widget.restaurante!.imageUrl;
    }
  }

  Future<void> salvar() async {
    if (!_formKey.currentState!.validate()) return;

    // aqui ajusta quando seu backend estiver aceitando POST
    final novo = Restaurante(
      id: widget.restaurante?.id ?? "0",
      nome: nomeController.text,
      endereco: enderecoController.text,
      usuarioId: widget.restaurante?.usuarioId ?? "",
      imageUrl: imageUrlController.text,
    );

    // TODO: implementar no controller salvar/editar restaurante
    Navigator.pop(context, novo);
  }

  @override
  Widget build(BuildContext context) {
    final editando = widget.restaurante != null;

    return Scaffold(
      appBar: AppBar(
        title: Text(editando ? "Editar Restaurante" : "Novo Restaurante"),
      ),
      body: Padding(
        padding: const EdgeInsets.all(16),
        child: Form(
          key: _formKey,
          child: Column(
            children: [
              TextFormField(
                controller: nomeController,
                decoration: const InputDecoration(labelText: "Nome"),
                validator: (v) => v!.isEmpty ? "Informe o nome" : null,
              ),
              TextFormField(
                controller: enderecoController,
                decoration: const InputDecoration(labelText: "Endereço"),
                validator: (v) => v!.isEmpty ? "Informe o endereço" : null,
              ),
              TextFormField(
                controller: imageUrlController,
                decoration: const InputDecoration(labelText: "URL da Imagem"),
              ),
              const SizedBox(height: 20),
              ElevatedButton(
                onPressed: salvar,
                child: Text(editando ? "Salvar Alterações" : "Cadastrar"),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
