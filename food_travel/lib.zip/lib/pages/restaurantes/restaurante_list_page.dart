import 'package:flutter/material.dart';
import '../../controllers/restaurante_controller.dart';
import '../../models/restaurante.dart';
import 'restaurante_form_page.dart';
import 'restaurant_detail_page.dart';

class RestauranteListPage extends StatefulWidget {
  const RestauranteListPage({super.key});

  @override
  State<RestauranteListPage> createState() => _RestauranteListPageState();
}

class _RestauranteListPageState extends State<RestauranteListPage> {
  final controller = RestauranteController();
  List<Restaurante> restaurantes = [];
  bool loading = true;

  @override
  void initState() {
    super.initState();
    carregar();
  }

  Future<void> carregar() async {
    setState(() => loading = true);

    final data = await controller.listarRestaurantes();

    restaurantes = data.map<Restaurante>((json) => Restaurante.fromJson(json)).toList();

    setState(() => loading = false);
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text("Restaurantes"),
        actions: [
          IconButton(
            icon: const Icon(Icons.refresh),
            onPressed: carregar,
          )
        ],
      ),
      floatingActionButton: FloatingActionButton(
        onPressed: () async {
          await Navigator.push(
            context,
            MaterialPageRoute(builder: (_) => RestauranteFormPage()),
          );
          carregar();
        },
        child: const Icon(Icons.add),
      ),
      body: loading
          ? const Center(child: CircularProgressIndicator())
          : ListView.builder(
              itemCount: restaurantes.length,
              itemBuilder: (context, index) {
                final r = restaurantes[index];
                return Card(
                  margin: const EdgeInsets.all(8),
                  child: ListTile(
                    leading: ClipRRect(
                      borderRadius: BorderRadius.circular(8),
                      child: Image.network(
                        r.imageUrl,
                        width: 60,
                        height: 60,
                        fit: BoxFit.cover,
                        errorBuilder: (_, __, ___) =>
                            const Icon(Icons.image_not_supported),
                      ),
                    ),
                    title: Text(r.nome),
                    subtitle: Text(r.endereco),
                    onTap: () {
                      Navigator.push(
                        context,
                        MaterialPageRoute(
                          builder: (_) => RestaurantDetailPage(restaurante: r),
                        ),
                      );
                    },
                  ),
                );
              },
            ),
    );
  }
}
