import 'package:flutter/material.dart';
import '../../services/food_travel_service.dart';
import '../../models/restaurante.dart';
import '../../models/prato.dart';
import '../../widgets/app_drawer.dart';

class HomePage extends StatefulWidget {
  const HomePage({super.key});

  @override
  State<HomePage> createState() => _HomePageState();
}

class _HomePageState extends State<HomePage> {
  final FoodTravelService service = FoodTravelService();

  List<Restaurante> restaurantes = [];
  bool loading = true;

  @override
  void initState() {
    super.initState();
    carregarRestaurantes();
  }

  Future<void> carregarRestaurantes() async {
    final data = await service.listarRestaurantes();
    setState(() {
      restaurantes = data;
      loading = false;
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text("Restaurantes")),

      drawer: Drawer(
        child: ListView(
          children: [
            const DrawerHeader(
              decoration: BoxDecoration(color: Colors.blue),
              child: Text(
                "Food Travel",
                style: TextStyle(color: Colors.white, fontSize: 22),
              ),
            ),

            ListTile(
              leading: const Icon(Icons.home),
              title: const Text("Home"),
              onTap: () => Navigator.pushReplacementNamed(context, "/home"),
            ),

            ListTile(
              leading: const Icon(Icons.restaurant),
              title: const Text("Restaurantes"),
              onTap: () => Navigator.pushNamed(context, "/restaurantes"),
            ),

            ListTile(
              leading: const Icon(Icons.fastfood),
              title: const Text("Pratos"),
              onTap: () => Navigator.pushNamed(context, "/pratos"),
            ),

            ListTile(
              leading: const Icon(Icons.favorite),
              title: const Text("Favoritos"),
              onTap: () => Navigator.pushNamed(context, "/favoritos"),
            ),

            ListTile(
              leading: const Icon(Icons.star),
              title: const Text("Avaliações"),
              onTap: () => Navigator.pushNamed(context, "/avaliacoes"),
            ),

            ListTile(
              leading: const Icon(Icons.person),
              title: const Text("Usuários"),
              onTap: () => Navigator.pushNamed(context, "/usuarios"),
            ),

            const Divider(),

            ListTile(
              leading: const Icon(Icons.logout),
              title: const Text("Sair"),
              onTap: () {
                Navigator.pushReplacementNamed(context, "/login");
              },
            ),
          ],
        ),
      ),

      body: loading
          ? const Center(child: CircularProgressIndicator())
          : ListView.builder(
              itemCount: restaurantes.length,
              itemBuilder: (context, index) {
                final r = restaurantes[index];
                return ListTile(
                  leading: r.imagemUrl != null
                      ? Image.network(
                          r.imagemUrl!,
                          width: 60,
                          height: 60,
                          fit: BoxFit.cover,
                        )
                      : const Icon(Icons.restaurant),
                  title: Text(r.nome),
                  subtitle: Text(r.endereco),
                  onTap: () async {
                    final pratos =
                        await service.listarPratosPorRestaurante(r.id);
                    Navigator.pushNamed(context, "/pratos",
                        arguments: pratos);
                  },
                );
              },
            ),
    );
  }
}
