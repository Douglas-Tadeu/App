import 'package:flutter/material.dart';
import 'pages/home/home_page.dart';
import 'pages/usuario/usuario_list_page.dart';
import 'pages/usuario/usuario_form_page.dart';
import 'pages/pratos/prato_list_page.dart';

void main() {
  runApp(const App());
}

class App extends StatelessWidget {
  const App({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      title: 'Food Travel',
      theme: ThemeData(
        primarySwatch: Colors.deepOrange,
        useMaterial3: true,
      ),
      initialRoute: '/',
      routes: {
        '/': (context) => const HomePage(),
        '/usuarios': (context) => const UsuarioListPage(),
        '/favoritos': (context) => const FavoritosUsuarioPage(),
        '/usuario-form': (context) => const UsuarioFormPage(),
        '/pratos': (context) {
          final pratos = ModalRoute.of(context)!.settings.arguments;
          return PratoListPage(pratos: pratos);
        },
      },
    );
  }
}
